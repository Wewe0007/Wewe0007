package org.tron.core.exception;

public class ZksnarkException extends TronException {

  public ZksnarkException() {
    super();
  }

  public ZksnarkException(String message) {
    super(message);
  }
}
